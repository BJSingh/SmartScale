// (c) 2014 Don Coleman
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

'use strict';

var smartScale = {
    service: "19B10010-E8F2-537E-4F6C-D104768A1214",
    weightCharaterisctics: "19B10011-E8F2-537E-4F6C-D104768A1214",
    tareBtnCharateristics:"19B10012-E8F2-537E-4F6C-D104768A1214",
    timerCharaterictics:"19B10013-E8F2-537E-4F6C-D104768A1214",
    buzzerCharateristics:"19B10014-E8F2-537E-4F6C-D104768A1214"
};

var weightNotifyCheck =1;
var deviceScanned = [];
var deviceCount = 0;
var connectedBleId;
var pairedDeviceInfo;


var totalCalories = 0;
var totalFat = 0;
var totalCarbs = 0;
var totalProtein = 0;

var storedCalories = 0;
var storedFat = 0;
var storedCarbs = 0;
var storedProtein = 0;

var app = {
    initialize: function() {
        this.bindEvents();
    },
    bindEvents: function() {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        refreshButton.addEventListener('touchstart', this.refreshDeviceList, false);
    },
    onDeviceReady: function() {
      var onSuccessBleEnabled = function (){
        alert("Bluetooth is enabled");
      }
      var onFailedBleEnabled = function (){
        alert("The user did *not* enable Bluetooth");
      }
      ble.enable(onSuccessBleEnabled,onFailedBleEnabled);
      app.refreshDeviceList();
    },
    refreshDeviceList: function() {
        deviceList.innerHTML = ''; // empties the list
        // scan for all devices
        ble.scan([], 5, app.onDiscoverDevice, app.onError);
    },
    onDiscoverDevice: function(device) {
        console.log(JSON.stringify(device));
        deviceScanned[deviceCount]= device;
        //alert(JSON.stringify(deviceScanned[deviceCount].id));
        var listItem = document.createElement('li'),
            html = '<b>' + device.name + '</b><br/>' +
                'RSSI: ' + device.rssi + '&nbsp;|&nbsp;' +
                device.id;

        listItem.innerHTML = html;
        deviceList.appendChild(listItem);
        deviceCount = deviceCount + 1;
    },
    connect: function() {
        //alert("ready: " + connectedBleId);
        var onConnect = function(){
          $("#statusId").text("Connected to " + pairedDeviceInfo);
          $( ":mobile-pagecontainer" ).pagecontainer( "change", "#detailPage", { role: "page",transition: "slideup" } );
          setTimeout(function(){
              $("#statusId").text("");
            },1000);
        }

        ble.connect(connectedBleId, onConnect, app.onError);
    },
    disconnect: function() {
        var onDisconnect = function(){
          $("#statusId").text("");
          $( ":mobile-pagecontainer" ).pagecontainer( "change", "#mainPage", { role: "page",transition: "slidedown" } );
        }

        ble.disconnect(connectedBleId, onDisconnect, app.onError);
    },
    onWeightLevelChange: function(data) {
        console.log(data);
        //alert(JSON.stringify(data));
        var a = new Int16Array(data);
        foodWeightId.innerHTML = a[0];
        productWeightId.innerHTML = a[0];
        app.nutritionCalculation();
    },
    notifyWeightState: function() {
        console.log("notifyWeightState");
        if(weightNotifyCheck==1){
          weightNotifyCheck = 0;
          ble.startNotification(connectedBleId, smartScale.service, smartScale.weightCharaterisctics, app.onWeightLevelChange, app.onError);
        }
        else {
          weightNotifyCheck = 1;
          var success = function(){
            alert("Weight Notify Stopped");
          }
          ble.stopNotification(connectedBleId, smartScale.service, smartScale.weightCharaterisctics, success, app.onError);
        }
    },
    readWeightValue: function() {
        var onReadWeightLevel = function(data) {
            console.log(data);
            //alert(JSON.stringify(data));
            var a = new Int16Array(data);
            foodWeightId.innerHTML = a[0];
            productWeightId.innerHTML = a[0];
            app.nutritionCalculation();
        }
        ble.read(connectedBleId, smartScale.service, smartScale.weightCharaterisctics, onReadWeightLevel, app.onError);
    },
    sendTareCmd: function() { // send tare command to scale
        var success = function() {
            console.log("success");
        };

        var failure = function() {
            alert("Failed writing data to the weight scale");
        };

        var data = new Uint8Array(1);
        data[0] = 0x01;
        ble.writeWithoutResponse(connectedBleId, smartScale.service, smartScale.tareBtnCharateristics, data.buffer, success, failure);
    },
    sendTimerData: function() { // send timer value command to scale
        var success = function() {
            console.log("success");
        };

        var failure = function() {
            alert("Failed writing data to the weight scale");
        };

        var timeVal = $("#timerInputId").val() + " Min";
        confirm(timeVal);

        var data = new Uint16Array(1);
        data[0] = $("#timerInputId").val();
        ble.writeWithoutResponse(connectedBleId, smartScale.service, smartScale.timerCharaterictics, data.buffer, success, failure);
    },
    sendBuzzerCmd: function() { // send stop buzzer command to scale
        var success = function() {
            console.log("success");
        };

        var failure = function() {
            alert("Failed writing data to the weight scale");
        };

        var data = new Uint8Array(1);
        data[0] = 0x01;
        ble.writeWithoutResponse(connectedBleId, smartScale.service, smartScale.buzzerCharateristics, data.buffer, success, failure);
    },
    nutritionCalculation: function(){
      var latestWeight = foodWeightId.innerHTML;
      totalCalories = (storedCalories*latestWeight)/100;
      totalFat = (storedFat*latestWeight)/100;
      totalCarbs = (storedCarbs*latestWeight)/100;
      totalProtein = (storedProtein*latestWeight)/100;

      tCaloriesId.innerHTML = totalCalories.toFixed(2);
      tFatId.innerHTML = totalFat.toFixed(2);
      tCarbsId.innerHTML = totalCarbs.toFixed(2);
      tProteinId.innerHTML = totalProtein.toFixed(2);
    },
    onError: function(reason) {
        alert("ERROR: " + reason);
    }
};

$('#deviceList').on('click', 'li', function() {
    var liIndex = $(this).index();
    //alert(id);
    connectedBleId = deviceScanned[liIndex].id;
    pairedDeviceInfo = deviceScanned[liIndex].name;
    confirm("connecting to "+ deviceScanned[liIndex].name + " "+ deviceScanned[liIndex].id);
    $("#statusId").text("connecting...");
    app.connect();

});

var app2 = angular.module('app2', []);

app2.controller('nutrientCtrl', function($scope) {

  $scope.foodList = [{id:0, foodName:'Apple', calories:52.00,fat:0.17,carbs:13.81,protein:0.26},
                    {id:1, foodName:'Grapes', calories:69.00,fat:0.16,carbs:18.10,protein:0.72},
                    {id:2, foodName:'Carrots', calories:41.00,fat:0.24,carbs:9.58,protein:0.93},
                    {id:3, foodName:'Banana', calories:89.00,fat:0.33,carbs:22.84,protein:1.09},
                    {id:4, foodName:'Almonds', calories:578.00,fat:50.64,carbs:19.74,protein:21.26},
                    {id:5, foodName:'Cashew nuts', calories:553.00,fat:43.85,carbs:30.19,protein:18.22},
                    {id:6, foodName:'Ginger', calories:80.00,fat:0.75,carbs:17.77,protein:1.82},
                    {id:7, foodName:'Peanuts', calories:599,fat:52.50,carbs:15.26,protein:28.03},
                    {id:8, foodName:'Dry Dates', calories:284.00,fat:0.6,carbs:76,protein:2.8}
                    ];


  $scope.addFood = function() {
      var assignId = $scope.foodList.length;
      $scope.foodList.push({id:assignId, foodName:$scope.nameInput, calories:$scope.caloriesInput, fat:$scope.fatInput, carbs:$scope.carbsInput, protein:$scope.proteinInput});
      $scope.nameInput = "";
      $scope.caloriesInput = "";
      $scope.fatInput = "";
      $scope.carbsInput = "";
      $scope.proteinInput = "";
      alert("Successfully added!");
  };

  $scope.foodDetect = function(obj){
    //alert($scope.foodList[obj].foodName);
    $scope.foodSelected = $scope.foodList[obj].foodName;
    storedCalories = $scope.foodList[obj].calories;
    storedFat = $scope.foodList[obj].fat;
    storedCarbs = $scope.foodList[obj].carbs;
    storedProtein = $scope.foodList[obj].protein;
    $( ":mobile-pagecontainer" ).pagecontainer( "change", "#nutrientPage", { role: "page",transition: "flip" } );
  }

});
