Android App made using cordova platform, you can find reference how to build on https://cordova.apache.org/docs/en/latest/guide/platforms/android/

App is made to connect Intel arduino 101 BLE board for smart scale project post on Devpost for intelHacks contest

BLE App reference
https://github.com/don/cordova-plugin-ble-central
https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/ArrayBuffer

Plugin Needed:
cordova-plugin-ble-central
